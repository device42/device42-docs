For details on usage please visit:
https://docs.device42.com/auto-discovery/agent-based-offline-discovery/