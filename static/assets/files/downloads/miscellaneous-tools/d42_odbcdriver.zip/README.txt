Device42 ODBC Driver v1.0.3 README

You may check for and download the latest version of this driver via https://www.device42.com/integrations/

For installation instructions, visit the ODBC Driver Integration page on the Device42 Documentation site:
https://docs.device42.com/external-integrations/odbc-driver-integration/

Should you have any issues that are not addressed by the documentation, feel free to open a support ticket @ https://support.device42.com or email support@device42.com.