Device42 JDBC Driver v1.0.2 README

You may check for and download the latest version of this driver via https://www.device42.com/miscellaneous-tools/

For installation instructions, visit the JDBC Driver Integration page on the Device42 Documentation site:
https://docs.device42.com/external-integrations/jdbc-driver-integration/

Should you have any issues that are not addressed by the documentation, feel free to open a support ticket @ https://support.device42.com or email support@device42.com.

RELEASE HISTORY
---------------
1.0.2
Fixed issue where the driver gave an error when used with Device42 17.02.00+.

1.0.1
Fixed issue when using a long DOQL query.

1.0.0
Initial Release