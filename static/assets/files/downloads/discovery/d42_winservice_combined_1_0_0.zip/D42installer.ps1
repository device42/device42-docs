# Function to safely get environment variable with a fallback default value
function Get-EnvVariable($varName, $default) {
    $value = [System.Environment]::GetEnvironmentVariable($varName)
    if ([string]::IsNullOrEmpty($value)) {
        return $default
    }
    return $value
}

# Use environment variables for paths with fallbacks
$programFilesPath = Join-Path (Get-EnvVariable "ProgramFiles" "C:\Program Files") "Device42"
$programDataPath = Join-Path (Get-EnvVariable "ProgramData" "C:\ProgramData") "Device42"

# Check if either "d42_winagent_x64.exe" or "d42_winagent.exe" exists
if (-not (Test-Path -Path ".\d42_winagent_x64.exe") -and -not (Test-Path -Path ".\d42_winagent.exe")) {
    Write-Error "Neither d42_winagent_x64.exe nor d42_winagent.exe exists in the current directory."
    exit
}

# Function to create a directory if it doesn't exist
function CreateDirectory($path) {
    if (-not (Test-Path -Path $path)) {
        try {
            New-Item -ItemType Directory -Path $path -ErrorAction Stop
        } catch {
            Write-Error "Failed to create directory at $path"
            exit
        }
    }
}

# Create directories
CreateDirectory $programFilesPath
CreateDirectory $programDataPath

# Determine the files to copy based on architecture
if ([System.IntPtr]::Size -eq 8) {
    # 64-bit files
    $filesToCopy = @("d42_winservice_x64_v1_0_0.exe", "d42_winagent_x64.exe")
    $configFile = "d42config.example_x64.json"
} else {
    # 32-bit files
    $filesToCopy = @("d42_winservice_386_v1_0_0.exe", "d42_winagent.exe")
    $configFile = "d42config.example_386.json"
}

# Copy the specified files from the current directory to the application folder
foreach ($file in $filesToCopy) {
    $filePath = ".\" + $file
    if (Test-Path -Path $filePath) {
        Copy-Item -Path $filePath -Destination $programFilesPath
    }
}

# Copy the correct config file to 'Program Files\Device42' and rename it
$configFilePath = ".\" + $configFile
$destinationConfigPath = Join-Path $programDataPath "d42config.json"
if (Test-Path -Path $configFilePath) {
    Copy-Item -Path $configFilePath -Destination $destinationConfigPath
}

# Create and describe the service
sc.exe create d42AgentService binPath= (Join-Path $programFilesPath $filesToCopy[0]) start= auto
sc.exe description d42AgentService "D42 service that calls the agent to run every N hours to send inventory details to Device42"

#optionally start the service
sc.exe start d42AgentService